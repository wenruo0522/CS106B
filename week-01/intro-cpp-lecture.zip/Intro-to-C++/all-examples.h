#pragma once

// functions we use in all-examples.cpp

int factorial(int number); // definition before use
void printTenTimes(char c);
int doubleValue(int x);
void doubleValueWithRef(int &x);
int square(int x);
bool even(int value);
